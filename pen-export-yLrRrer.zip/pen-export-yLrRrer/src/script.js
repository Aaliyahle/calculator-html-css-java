let timer;
let hours = 0;
let minutes = 0;
let seconds = 0;

function startStop() {
  if (timer) {
    clearInterval(timer);
    document.getElementById('startStopButton').textContent = 'Start';
    timer = null;
  } else {
    document.getElementById('startStopButton').textContent = 'Stop';
    timer = setInterval(updateTime, 1000);
  }
}

function reset() {
  clearInterval(timer);
  timer = null;
  document.getElementById('startStopButton').textContent = 'Start';
  hours = 0;
  minutes = 0;
  seconds = 0;
  updateTime();
}

function updateTime() {
  seconds++;
  if (seconds >= 60) {
    seconds = 0;
    minutes++;
    if (minutes >= 60) {
      minutes = 0;
      hours++;
    }
  }
  document.getElementById('hours').textContent = pad(hours);
  document.getElementById('minutes').textContent = pad(minutes);
  document.getElementById('seconds').textContent = pad(seconds);
}

function pad(value) {
  return value < 10 ? '0' + value : value;
}
